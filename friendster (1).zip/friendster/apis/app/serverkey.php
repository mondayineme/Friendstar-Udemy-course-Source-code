<?php
if (!defined('API_ACCESS_KEY')) {
		define( 'API_ACCESS_KEY', 'ADD_YOUR_SERVER_KEY' );
	}
?>