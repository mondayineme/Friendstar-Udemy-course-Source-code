<?php
if(!defined('IS_APP_LIVE')){
    define('IS_APP_LIVE',false); 
}

require_once __DIR__ .'/../bootstrap/app.php';

